import { describe, expect, it } from "vitest";
import { OrderRepository } from "#state/order-repository.js";

describe("OrderRepository", () => {
  const repository = new OrderRepository();

  it("throws on every unimplemented method", async () => {
    await expect(repository.save({})).rejects.toThrow();
    await expect(repository.findByIdempotencyKey("k")).rejects.toThrow();
    await expect(repository.findByBrokerOrderId("b")).rejects.toThrow();
    await expect(repository.update("k", {})).rejects.toThrow();
    await expect(repository.findAllOpen()).rejects.toThrow();
  });
});
