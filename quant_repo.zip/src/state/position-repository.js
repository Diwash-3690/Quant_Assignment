export class PositionRepository {
  async find(tradingSymbol, exchange) {
    throw new Error("find() not implemented");
  }

  async upsert(position) {
    throw new Error("upsert() not implemented");
  }

  async findAll() {
    throw new Error("findAll() not implemented");
  }
}
