# qts

Quant trading system: live grid / stop-and-reverse execution, technical
analysis, macro regime engine, Zerodha Kite Connect integration, and
bar-accurate backtesting for MCX and NSE.

## Setup

Requires a running PostgreSQL instance. Apply the migrations in
`db/migrations/` in order (no migration tool is wired up yet — run them
by hand against your database until one is added).

```
npm install
```

## Layout

```
src/
  config/         configuration loading
  domain/         instrument, order, position, signal models
  ta/             trend, momentum, volatility, volume indicators
  regime/         macro proxies, regime scoring, parameter overrides
  execution/      grid and stop-and-reverse engines
  broker/         broker interface and Kite Connect adapter
  state/          order/position state and reconciliation
  backtest/       bar-accurate backtest engine
  observability/  structured logging and alerting
```

Internal imports use Node's native subpath imports, aliased with the `#`
prefix (e.g. `import { Order } from "#domain/order.js"`), configured in
`package.json` under `imports` and mirrored in `jsconfig.json` for editor
resolution.

## Design decisions and known gaps

- **Money** is plain JS numbers in rupees, matching Kite Connect's own API
  convention, not integer paise or a decimal library. Precision is enforced
  by funneling every order price through `domain/money.js#roundToTick`
  (tick-size correctness) and every P&L/average-price calculation through
  `roundToPaisa` (currency precision) — two separate functions because they
  answer different questions.
- **Persistence** is PostgreSQL, for order state, position state, and
  eventually tick data. `execution/grid-engine.js` and
  `execution/sar-engine.js` do **not** persist their own state (grid legs,
  SAR direction/cycle, kill-switch flag) — only the orders and positions
  they produce are durable. A process restart currently loses in-flight
  grid/SAR shape even though the underlying orders/positions survive.
- **`placeOrder` is never automatically retried.** Kite has no
  idempotency-key mechanism at the API level, so blindly retrying a timed-out
  placement risks a duplicate live order. `state/order-state.js` writes
  intent to Postgres as `PENDING` *before* calling the broker, and
  `state/reconciliation.js` is what's allowed to actually retry — only
  after confirming via `fetchOrders()` that the broker never received the
  original attempt.
- **Kite's login/session flow is out of scope so far.** `KiteRestClient`
  expects to be handed an already-valid `accessToken`; the daily
  `request_token` → `access_token` exchange isn't built yet.
- **`ta/volume.js#vwap` is session-agnostic.** It accumulates over whatever
  bars it's given; resetting at the start of each trading session is the
  caller's responsibility, not baked into the function.
- **Stops in `SarEngine` only move on discrete events** (a pyramid add or a
  reversal), not continuously on every tick — trailing on every tick would
  mean constant order-modification calls against Kite's rate limits for
  marginal benefit.

## Test

```
npm test
```

