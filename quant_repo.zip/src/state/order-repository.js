export class OrderRepository {
  async save(order) {
    throw new Error("save() not implemented");
  }

  async findByIdempotencyKey(idempotencyKey) {
    throw new Error("findByIdempotencyKey() not implemented");
  }

  async findByBrokerOrderId(brokerOrderId) {
    throw new Error("findByBrokerOrderId() not implemented");
  }

  async update(idempotencyKey, changes) {
    throw new Error("update() not implemented");
  }

  async findAllOpen() {
    throw new Error("findAllOpen() not implemented");
  }
}
