import { describe, expect, it } from "vitest";
import { PositionRepository } from "#state/position-repository.js";

describe("PositionRepository", () => {
  const repository = new PositionRepository();

  it("throws on every unimplemented method", async () => {
    await expect(repository.find("X", "MCX")).rejects.toThrow();
    await expect(repository.upsert({})).rejects.toThrow();
    await expect(repository.findAll()).rejects.toThrow();
  });
});
